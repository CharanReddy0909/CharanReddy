# Employee Management System
A Spring Boot based CRUD app with CI/CD, Docker, Kubernetes, and monitoring.