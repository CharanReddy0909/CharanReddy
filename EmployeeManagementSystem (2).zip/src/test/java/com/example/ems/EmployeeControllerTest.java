package com.example.ems;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class EmployeeControllerTest {
    @Test
    void contextLoads() {
        assertThat(true).isTrue();
    }
}