package com.aryan.ecom.enums;

public enum UserRole {
	ADMIN,
	CUSTOMER
}
